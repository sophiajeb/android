package com.example.crudwithsqlite;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.view.View;
import android.widget.Button;

import android.os.Bundle;

public class ViewAllActivity extends AppCompatActivity {

    DatabaseHelper myDB  = new DatabaseHelper(this);
    MainActivity main = new MainActivity();
    Button viewAllActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all);

        viewAllActivity = findViewById(R.id.btn_viewAllActivity);

        viewAll();
    }


    public void viewAll(){
        viewAllActivity.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res = myDB.getAllData();
                        if (res.getCount() == 0){
                            showMessage("Error", "Nothing Found");
                            return;
                        }
                        StringBuffer buffer = new StringBuffer();
                        while(res.moveToNext()){
                            buffer.append("Id :" + res.getString(0)+"\n");
                            buffer.append("Title :" + res.getString(1)+"\n");
                            buffer.append("Director :" + res.getString(2)+"\n");
                            buffer.append("Duration :" + res.getString(3)+"\n");
                            buffer.append("Film Type :" + res.getString(4)+"\n");
                            buffer.append("Production Year :" + res.getString(5)+"\n\n");
                        }
                        // Show all data
                        showMessage("Data",buffer.toString());
                    }
                }
        );
    }

    public void showMessage(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

}
