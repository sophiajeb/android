package com.example.crudwithsqlite;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainProject extends AppCompatActivity {

    DatabaseHelper myDB;
    EditText id, title, director, duration, film_type, product_year;
    Button button_add;
    Button button_view_all;
    Button button_view_update;
    Button button_delete;
    Button button_movies_where_title;
    Button button_like;
    Button button_director;
    Button delete;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDB = new DatabaseHelper(this);

        id = findViewById(R.id.id);
        title = findViewById(R.id.title);
        director = findViewById(R.id.director);
        duration = findViewById(R.id.duration);
        film_type = findViewById(R.id.film_type);
        product_year = findViewById(R.id.product_year);
        button_add = findViewById(R.id.button_add);
        button_view_all = findViewById(R.id.btn_viewAll);
        button_view_update = findViewById(R.id.updateBtn);
        button_delete =findViewById(R.id.delete);
        button_movies_where_title = findViewById(R.id.moviesWhereTitle);
        button_like = findViewById(R.id.BtnLike);
        button_director = findViewById(R.id.BtnDirector);
        delete = findViewById(R.id.delete);

        button_view_all.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityViewAll();
            }
        });


        AddData();
        UpdateData();
        viewWhereTitleIs();
        viewWhereTitleLike();
        viewWhereDirectoris();
        DeleteData();
    }




    public void openActivityViewAll(){
        Intent intent = new Intent(this, ViewAllActivity.class);
        startActivity(intent);

    }



    public void AddData (){
        button_add.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isInserted = myDB.insertData(
                                title.getText().toString(),
                                director.getText().toString(),
                                duration.getText().toString(),
                                film_type.getText().toString(),
                                product_year.getText().toString()
                        );
                        if (isInserted == true) {
                            Toast.makeText(MainProject.this, "Data is Inserted", Toast.LENGTH_LONG).show();
                        }else {
                            Toast.makeText(MainProject.this, "Data not Inserted", Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );
    }

    public void viewWhereTitleIs(){
        button_movies_where_title.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res = myDB.getWhereTitleis(title.getText().toString());
                        if (res.getCount() == 0){
                            showMessage("Error", "Nothing Found");
                            return;
                        }
                        StringBuffer buffer = new StringBuffer();
                        while(res.moveToNext()){
                            buffer.append("Id :" + res.getString(0)+"\n");
                            buffer.append("Title :" + res.getString(1)+"\n");
                            buffer.append("Director :" + res.getString(2)+"\n");
                            buffer.append("Duration :" + res.getString(3)+"\n");
                            buffer.append("Film Type :" + res.getString(4)+"\n");
                            buffer.append("Production Year :" + res.getString(5)+"\n\n");
                        }
                        // Show all data
                        showMessage("Data",buffer.toString());
                    }
                }
        );
    }



    public void viewWhereDirectoris(){
        button_director.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res = myDB.getWhereDirectorIs(director.getText().toString());
                        if (res.getCount() == 0){
                            showMessage("Error", "Nothing Found");
                            return;
                        }
                        StringBuffer buffer = new StringBuffer();
                        while(res.moveToNext()){
                            buffer.append("Id :" + res.getString(0)+"\n");
                            buffer.append("Title :" + res.getString(1)+"\n");
                            buffer.append("Director :" + res.getString(2)+"\n");
                            buffer.append("Duration :" + res.getString(3)+"\n");
                            buffer.append("Film Type :" + res.getString(4)+"\n");
                            buffer.append("Production Year :" + res.getString(5)+"\n\n");
                        }
                        // Show all data
                        showMessage("Data",buffer.toString());
                    }
                }
        );
    }

    public void viewWhereTitleLike(){
        button_like.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res = myDB.getWhereTitleLike(title.getText().toString());
                        if (res.getCount() == 0){
                            showMessage("Error", "Nothing Found");
                            return;
                        }
                        StringBuffer buffer = new StringBuffer();
                        while(res.moveToNext()){
                            buffer.append("Id :" + res.getString(0)+"\n");
                            buffer.append("Title :" + res.getString(1)+"\n");
                            buffer.append("Director :" + res.getString(2)+"\n");
                            buffer.append("Duration :" + res.getString(3)+"\n");
                            buffer.append("Film Type :" + res.getString(4)+"\n");
                            buffer.append("Production Year :" + res.getString(5)+"\n\n");
                        }
                        // Show all data
                        showMessage("Data",buffer.toString());
                    }
                }
        );
    }


    public void showMessage(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }


    public void UpdateData(){
        button_view_update.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isUpdated = myDB.updateData(id.getText().toString(),
                                title.getText().toString(),
                                director.getText().toString(),
                                duration.getText().toString(),
                                film_type.getText().toString(),
                                product_year.getText().toString());
                        if (isUpdated == true) {
                            Toast.makeText(MainProject.this, "Data is Updated", Toast.LENGTH_LONG).show();
                        }else {
                            Toast.makeText(MainProject.this, "Data not Updated", Toast.LENGTH_LONG).show();
                        }
                    }

                }
        );
    }

    public void DeleteData(){
        delete.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Integer deletedRows = myDB.deleteData(id.getText().toString());
                        if(deletedRows > 0){
                            Toast.makeText(MainProject.this, "Data Deleted", Toast.LENGTH_LONG).show();
                        }else {
                            Toast.makeText(MainProject.this, "Data not Deleted", Toast.LENGTH_LONG).show();

                        }
                    }
                }
        );
    }



}
